sap.ui.define([
	"com/sample/ZSVoiceRecord/test/unit/controller/View1.controller"
], function () {
	"use strict";
});